package com.bharath.learning.hibernate;// Java Program to Illustrate Creation of Simple POJO Class

// Importing required classes from JPA
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.SequenceGenerator;

@Entity
@Table(name = "SONGS")
// POJO class
public class Song {

	@Id
	@Column(name = "songId")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqid-gen")
	@SequenceGenerator(name = "seqid-gen", sequenceName = "SONG_SEQ",initialValue = 1, allocationSize = 1)
	private int id;

	@Column(name = "songName")
	private String songName;

	@Column(name = "singer")
	private String artist;

	public int getId() { return id; }

	public void setId(int id) { this.id = id; }

	public String getSongName() { return songName; }

	public void setSongName(String songName)
	{
		this.songName = songName;
	}

	public String getArtist() { return artist; }

	public void setArtist(String artist)
	{
		this.artist = artist;
	}
}
