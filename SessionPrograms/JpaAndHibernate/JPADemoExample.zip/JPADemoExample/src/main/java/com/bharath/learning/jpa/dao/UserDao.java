package com.bharath.learning.jpa.dao;

import com.bharath.learning.jpa.model.User;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

import java.util.List;

public class UserDao {

    public  void updateExistingUser(EntityManager entityManager) {
        entityManager.getTransaction().begin();
        User existingUser = new User();
        existingUser.setId(2);
        existingUser.setEmail("bharath.ashok@gmail.com");
        existingUser.setFullname("Bharath Ashok");
        existingUser.setPassword("---------Guru------");

        entityManager.merge(existingUser);
        entityManager.getTransaction().commit();
    }

    public  void createNewUser(EntityManager entityManager) {

        User newUser = new User();
        newUser.setEmail("bharath@gmail.com");
        newUser.setFullname("Bharath Trainer");
        newUser.setPassword("billionaire");

        entityManager.persist(newUser);

    }

    public  void findUser(EntityManager entityManager) {
        Integer primaryKey = 2;
        User user = entityManager.find(User.class, primaryKey);

        System.out.println(user.getEmail());
        System.out.println(user.getFullname());
        System.out.println(user.getPassword());
    }

    public  void findUserByQuery(EntityManager entityManager) {
        String sql = "SELECT u from User u where u.email = 'bharath@gmail.com'";
        Query query = entityManager.createQuery(sql);
        List<User> usersList = query.getResultList();

        usersList.stream().forEach(user -> {
            System.out.println(user.getEmail());
            System.out.println(user.getFullname());
            System.out.println(user.getPassword());
        });

    }

    public  void removeUser(EntityManager entityManager) {
        entityManager.getTransaction().begin();
        Integer primaryKey = 1;
        User reference = entityManager.getReference(User.class, primaryKey);
        entityManager.remove(reference);
        entityManager.getTransaction().commit();
    }
}
