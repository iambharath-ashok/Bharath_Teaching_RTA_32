package com.bharath.learning.jpa.entitystates;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Persistence;

public class Detached {

    public static void main(String[] args) {
        EntityManager em = Persistence.createEntityManagerFactory("").createEntityManager();

// Creating a new entity in a transient state
        User user = new User();
        user.setUserName("john_doe");
        user.setEmail("john@example.com");

// Persist the 'user' object to make it persistent (managed)
        em.getTransaction().begin();
        em.persist(user);
        em.getTransaction().commit();

// The 'user' object is in a persistent (managed) state

// Detach the 'user' object
        em.detach(user);

// Now, 'user' is in a detached state

// Changes to the 'user' object will not be automatically synchronized with the database
        user.setEmail("new_email@example.com");

// To reattach it, you can use merge or re-fetch it using em.find
        User mergedUser = em.merge(user);
// Now, 'user' is in a persistent (managed) state again

        em.getTransaction().begin();

// Changes to 'mergedUser' will be synchronized with the database when the transaction is committed
        mergedUser.setEmail("updated_email@example.com");

        em.getTransaction().commit();

        em.close();

// After closing the entity manager, both 'user' and 'mergedUser' become detached

    }
}
