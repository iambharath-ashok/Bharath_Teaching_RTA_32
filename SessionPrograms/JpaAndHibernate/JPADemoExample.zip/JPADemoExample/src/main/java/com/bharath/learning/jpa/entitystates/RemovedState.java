package com.bharath.learning.jpa.entitystates;
import jakarta.persistence.*;
public class RemovedState {

    public static void main(String[] args) {
        EntityManager em = Persistence.createEntityManagerFactory("").createEntityManager();

// Create or fetch a managed entity

        User user = em.find(User.class, 1);

// Mark the entity for removal
        em.getTransaction().begin();
        em.remove(user); // The entity is in the Removed (Deleted) state now
        em.getTransaction().commit(); // The entity is removed from the database

        em.close(); // The entity is now detached

    }
}
