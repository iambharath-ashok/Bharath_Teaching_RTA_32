package com.bharath.learning.jpa.entitystates;

import jakarta.persistence.*;
public class Transient {

    public static void main(String[] args) {
        EntityManager em = Persistence.createEntityManagerFactory("").createEntityManager();

// Creating a new entity in a transient state
        User user = new User();
        user.setUserName("john_doe");
        user.setEmail("john@example.com");

// The 'user' object is transient at this point because it's not associated with 'em'

        em.getTransaction().begin();

// Persist the 'user' object to make it persistent
        em.persist(user);

// Now, 'user' is in a persistent state, and any changes will be synchronized with the database

        em.getTransaction().commit();

// 'user' is still in a persistent state until the entity manager is closed or the 'user' is detached
        em.close();

// After closing the entity manager, 'user' becomes detached


    }
}
