package com.bharath.learning.jpa.runners;

import com.bharath.learning.jpa.dao.UserDao;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class UserJPADemoRunner {

    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("UsersDB");
        EntityManager entityManager = factory.createEntityManager();

        UserDao userDao = new UserDao();

        userDao.findUser(entityManager);
        userDao.createNewUser(entityManager);
        userDao.updateExistingUser(entityManager);
        userDao.findUserByQuery(entityManager);
        //userDao.removeUser(entityManager);

        entityManager.close();
        factory.close();
    }
}