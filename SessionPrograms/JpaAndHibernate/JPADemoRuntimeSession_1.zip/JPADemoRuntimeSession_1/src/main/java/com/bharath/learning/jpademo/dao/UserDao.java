package com.bharath.learning.jpademo.dao;

public class UserDao {
}
