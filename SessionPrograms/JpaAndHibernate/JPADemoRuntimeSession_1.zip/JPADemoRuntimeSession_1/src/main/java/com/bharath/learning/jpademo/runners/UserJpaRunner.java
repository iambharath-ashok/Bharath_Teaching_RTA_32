package com.bharath.learning.jpademo.runners;

import com.bharath.learning.jpademo.model.User;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class UserJpaRunner {

    public static void main(String[] args) {

        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("UsersDB");
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        entityManager.getTransaction().begin();
        User user1 = new User();
        user1.setEmail("Bharath.ashok@gmail.com");
        user1.setName("Bharath");
        user1.setPassword("PASSWORD");

        entityManager.persist(user1);

        entityManager.getTransaction().commit();

    }
}
