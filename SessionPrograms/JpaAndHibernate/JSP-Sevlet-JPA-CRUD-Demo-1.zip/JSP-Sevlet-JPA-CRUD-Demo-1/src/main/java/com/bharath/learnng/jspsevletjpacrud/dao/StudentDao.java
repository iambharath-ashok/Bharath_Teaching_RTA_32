package com.bharath.learnng.jspsevletjpacrud.dao;

import com.bharath.learnng.jspsevletjpacrud.model.Student;
import com.bharath.learnng.jspsevletjpacrud.util.JpaUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.List;

public class StudentDao {



    /**
     * Save Student
     * @param student
     */
    public void saveStudent(Student student) {
        EntityManager entityManager = JpaUtil.getEntityManager();
        EntityTransaction transaction = null;
        try {
            transaction = entityManager.getTransaction();
            transaction.begin();
            entityManager.persist(student);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null && transaction.isActive()) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            entityManager.close();
        }
    }

    /**
     * Update Student
     * @param student
     */
    public void updateStudent(Student student) {
        EntityManager entityManager = JpaUtil.getEntityManager();
        EntityTransaction transaction = null;
        try {
            transaction = entityManager.getTransaction();
            transaction.begin();
            entityManager.merge(student);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null && transaction.isActive()) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            entityManager.close();
        }
    }

    /**
     * Delete Student
     * @param id
     */
    public void deleteStudent(int id) {
        EntityManager entityManager = JpaUtil.getEntityManager();
        EntityTransaction transaction = null;
        try {
            transaction = entityManager.getTransaction();
            transaction.begin();
            Student student = entityManager.find(Student.class, id);
            if (student != null) {
                entityManager.remove(student);
                System.out.println("Student is deleted");
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null && transaction.isActive()) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            entityManager.close();
        }
    }

    /**
     * Get Student By ID
     * @param id
     * @return
     */
    public Student getStudent(int id) {
        EntityManager entityManager = JpaUtil.getEntityManager();
        EntityTransaction transaction = null;
        Student student = null;
        try {
            transaction = entityManager.getTransaction();
            transaction.begin();
            student = entityManager.find(Student.class, id);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null && transaction.isActive()) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            entityManager.close();
        }
        return student;
    }

    /**
     * Get all Students
     * @return
     */
    public List<Student> getAllStudents() {
        EntityManager entityManager = JpaUtil.getEntityManager();
        EntityTransaction transaction = null;
        List<Student> listOfStudents = null;
        try {
            transaction = entityManager.getTransaction();
            transaction.begin();
            listOfStudents = entityManager.createQuery("SELECT s FROM Student s", Student.class).getResultList();
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null && transaction.isActive()) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            entityManager.close();
        }
        return listOfStudents;
    }
}
