package com.bharath.learning.manytomanymapping.runners;

import com.bharath.learning.manytomanymapping.model.Movie;
import com.bharath.learning.manytomanymapping.model.SuperHero;
import com.bharath.learning.manytomanymapping.repository.MovieRepository;
import com.bharath.learning.manytomanymapping.repository.SuperHeroRepository;
import com.mysql.cj.Session;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.Optional;

public class JpaExample2 {

    public static void main(String[] args) {
        // Create our entity manager
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("ManyToManyMapping");
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        MovieRepository movieRepository = new MovieRepository(entityManager);
        SuperHeroRepository superHeroRepository = new SuperHeroRepository(entityManager);

        // Create some superheroes
        SuperHero ironman = new SuperHero("Iron Man");
        SuperHero thor = new SuperHero("Thor");

        // Create some movies
        Movie avengers = new Movie("The Avengers");
        avengers.addSuperHero(ironman);
        avengers.addSuperHero(thor);

        Movie infinityWar = new Movie("Avengers: Infinity War");
        infinityWar.addSuperHero(ironman);
        infinityWar.addSuperHero(thor);

        // Save the movies
        movieRepository.save(avengers);
        movieRepository.save(infinityWar);

        // Find all movies
        System.out.println("MOVIES:");
        movieRepository.findAll().forEach(movie -> {
            System.out.println("Movie: [" + movie.getId() + "] - " + movie.getTitle());
            movie.getSuperHeroes().forEach(System.out::println);
        });

        // Find all superheroes
        System.out.println("\nsuperheroes:");
        superHeroRepository.findAll().forEach(superHero -> {
            System.out.println(superHero);
            superHero.getMovies().forEach(System.out::println);
        });

        // Delete a movie and verify that its superheroes are not deleted
//        movieRepository.deleteById(1);
//        System.out.println("\nMOVIES (AFTER DELETE):");
//        movieRepository.findAll().forEach(movie -> {
//            System.out.println("Movie: [" + movie.getId() + "] - " + movie.getTitle());
//            movie.getSuperHeroes().forEach(System.out::println);
//        });
        System.out.println("\nsuperheroes (AFTER DELETE):");
        superHeroRepository.findAll().forEach(superHero -> {
            System.out.println(superHero);
            superHero.getMovies().forEach(System.out::println);
        });


        // DEBUG, dump our tables
       /* entityManager.unwrap(Session.class).doWork(connection ->
                JdbcUtils.dumpTables(connection, "MOVIE", "SUPER_HERO", "SUPERHERO_MOVIES"));*/

        // Close the entity manager and associated factory
        entityManager.close();
        entityManagerFactory.close();
    }
}