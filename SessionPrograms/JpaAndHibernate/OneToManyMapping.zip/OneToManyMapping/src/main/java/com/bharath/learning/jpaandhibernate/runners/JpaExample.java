package com.bharath.learning.jpaandhibernate.runners;

import com.bharath.learning.jpaandhibernate.models.library.Author;
import com.bharath.learning.jpaandhibernate.models.library.Book;
import com.bharath.learning.jpaandhibernate.repository.AuthorRepository;
import com.bharath.learning.jpaandhibernate.repository.BookRepository;


import jakarta.persistence.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class JpaExample {

    public static void main(String[] args) throws InterruptedException {
        // Create our entity manager
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("Books");
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        // Create our repositories
        BookRepository bookRepository = new BookRepository(entityManager);
        AuthorRepository authorRepository = new AuthorRepository(entityManager);

        // Create an author and add 3 books to his list of books
        Author author1 = getAuthor1();
        Optional<Author> savedAuthor = authorRepository.save(author1);
        System.out.println("Saved author: " + savedAuthor.get());

        Author author2 = getAuthor2();
        Optional<Author> savedAuthor2 = authorRepository.save(author2);
        System.out.println("Saved author: " + savedAuthor2.get());

        // Find all authors
        List<Author> authors = authorRepository.findAll();
        System.out.println("Authors:");
        authors.forEach(System.out::println);

        // Find author by name
        Optional<List<Author>> authorByName = authorRepository.findByName("Author 1");
        System.out.println("Searching for an author by name: ");
        authorByName.ifPresent(System.out::println);

        // Search for a book by ID
        Optional<Book> foundBook = bookRepository.findById(2);
        foundBook.ifPresent(System.out::println);

        // Search for a book with an invalid ID
        Optional<Book> notFoundBook = bookRepository.findById(99);
        notFoundBook.ifPresent(System.out::println);

        // List all books
        List<Book> books = bookRepository.findAll();
        System.out.println("Books in database:");
        books.forEach(System.out::println);

        // Find a book by name
        Optional<List<Book>> queryBook1 = bookRepository.findByName("Book 2");
        System.out.println("Query for book 2:");
        queryBook1.ifPresent(System.out::println);

        // Find a book by name using a named query
        Optional<List<Book>> queryBook2 = bookRepository.findByNameNamedQuery("Book 3");
        System.out.println("Query for book 3:");
        queryBook2.ifPresent(System.out::println);

        // Add a book to author 1
        Optional<Author> authorByid = authorRepository.findById(1);
        authorByid.ifPresent(a -> {
            a.addBook(new Book("Book 4"));
            System.out.println("Saved author: " + authorRepository.save(a));
        });



        // Close the entity manager and associated factory
        entityManager.close();
        entityManagerFactory.close();




        // Thread dump
        Thread.getAllStackTraces().forEach((thread, stackTrace) -> {
            System.out.println("Thread: " + thread.getName() + ", state=" + thread.getState());
            Arrays.stream(stackTrace).forEach(stackTraceElement -> {
                System.out.println("\t" + stackTraceElement.toString());
            });
        });
    }

    private static Author getAuthor1() {
        Author author = new Author("Author 1");
        author.addBook(new Book("Book 1"));
        author.addBook(new Book("Book 2"));
        author.addBook(new Book("Book 3"));
        return author;
    }

    private static Author getAuthor2() {
        Author author = new Author("Author 2");
        author.addBook(new Book("Book 5"));
        author.addBook(new Book("Book 7"));
        return author;
    }
}
