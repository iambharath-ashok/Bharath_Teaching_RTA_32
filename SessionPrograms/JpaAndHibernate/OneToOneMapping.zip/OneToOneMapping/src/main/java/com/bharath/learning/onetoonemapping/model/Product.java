package com.bharath.learning.onetoonemapping.model;

import jakarta.persistence.*;

@Entity
@Table(name = "PRODUCT")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqid-gen")
    @SequenceGenerator(name = "seqid-gen", sequenceName = "PRODUCT_SEQ",initialValue = 1, allocationSize = 1)
    @Column(name = "PRODUCT_ID")
    private long productId;

    private String name;
    private String description;
    private float price;

    @OneToOne(cascade = CascadeType.ALL)
    @PrimaryKeyJoinColumn
    //@JoinColumn(name = "PRODUCT_DESC_ID")
    private ProductDetail productDetail;
 
    public Product() {
    }

    public long getProductId() {
        return productId;
    }

    public void setProductId(long productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public ProductDetail getProductDetail() {
        return productDetail;
    }

    public void setProductDetail(ProductDetail productDetail) {
        this.productDetail = productDetail;
    }
    // other getters and setters
}