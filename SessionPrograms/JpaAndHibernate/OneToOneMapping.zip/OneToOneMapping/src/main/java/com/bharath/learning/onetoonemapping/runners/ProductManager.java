package com.bharath.learning.onetoonemapping.runners;

import com.bharath.learning.onetoonemapping.model.Product;
import com.bharath.learning.onetoonemapping.model.ProductDetail;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.List;

public class ProductManager {

    public static void main(String[] args) {

        EntityManagerFactory factory = Persistence.createEntityManagerFactory("OneToOneMapping");
        EntityManager entityManager = factory.createEntityManager();
        entityManager.getTransaction().begin();

        Product product = new Product();
        product.setName("Civic");
        product.setDescription("Comfortable, fuel-saving car");
        product.setPrice(20000);

        // creates product detail
        ProductDetail detail = new ProductDetail();
        detail.setPartNumber("ABCDEFGHIJKL");
        detail.setDimension("2,5m x 1,4m x 1,2m");
        detail.setWeight(1000);
        detail.setManufacturer("Honda Automobile");
        detail.setOrigin("Japan");

        // sets the bi-directional association
        product.setProductDetail(detail);
        detail.setProduct(product);

        entityManager.persist(product);
        entityManager.getTransaction().commit();


    //   List<Product> productList = entityManager.createQuery("FROM Product").getResultList();
        Product product1 =  entityManager.find(Product.class, 1);
        System.out.println(product1.getProductDetail());
        System.out.println(product1.getName());

    }
}
