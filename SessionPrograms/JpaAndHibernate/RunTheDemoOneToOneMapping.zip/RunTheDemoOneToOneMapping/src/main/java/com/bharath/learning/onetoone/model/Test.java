package com.bharath.learning.onetoone.model;

import java.util.Optional;
import java.util.stream.Stream;

public class Test {

    public static void main(String[] args) {
        String calibration = "Deleted";
        String actualStatus = null;

        if(actualStatus == null) {

        }

        boolean isMakertDataDeleted =  Optional.ofNullable(actualStatus)
                .map(status -> Stream.of("Deleted", "DeletionFailed").anyMatch(s -> s.equalsIgnoreCase(status))).orElse(false);
        if(isMakertDataDeleted) {
            System.out.println(isMakertDataDeleted);
        } else {
            System.out.println(isMakertDataDeleted);
        }

    }
}
