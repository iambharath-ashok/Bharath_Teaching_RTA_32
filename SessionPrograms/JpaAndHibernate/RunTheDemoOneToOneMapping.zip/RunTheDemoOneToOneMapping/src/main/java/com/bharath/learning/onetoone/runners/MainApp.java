package com.bharath.learning.onetoone.runners;

import com.bharath.learning.onetoone.model.Address;
import com.bharath.learning.onetoone.model.User;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class MainApp {

    public static void main(String[] args) {

        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("UsersDB");
        EntityManager em = entityManagerFactory.createEntityManager();
        EntityTransaction transaction= em.getTransaction();

        transaction.begin();

        User user = new User();
        user.setUsername("Bharath");

        Address address = new Address();
        address.setCity("Bangalore");
        address.setStreet("Marathahalli");

        user.setAddress(address);
        address.setUser(user);

        em.persist(user);



        User retrievedUser = em.find(User.class, 1);
         System.out.println(retrievedUser.getUsername());
         System.out.println(retrievedUser.getAddress());

         transaction.commit();
    }
}
