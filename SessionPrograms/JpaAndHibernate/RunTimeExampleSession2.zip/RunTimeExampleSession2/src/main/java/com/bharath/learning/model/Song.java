package com.bharath.learning.model;


import javax.persistence.*;

@Entity
public class Song {
    @Id
    @Column(name = "SONG_ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    private String songName;

    private String singer;

    private String year;

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSongName() {
        return songName;
    }

    public void setSongName(String songName) {
        this.songName = songName;
    }

    public String getSinger() {
        return singer;
    }

    public void setSinger(String singer) {
        this.singer = singer;
    }
}
