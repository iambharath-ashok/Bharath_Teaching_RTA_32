package com.bharath.learning.runner;

import com.bharath.learning.model.Song;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class SongPlaylistRunner {

    public static void main(String[] args) {

        Configuration configuration = new Configuration();
        configuration.configure("META-INF/hibernate.cfg.xml");
        configuration.addAnnotatedClass(Song.class);

        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();

        session.beginTransaction();

        Song song = new Song();
       // song.setId(2l);
        song.setSongName("Song1");
        song.setSinger("Singer1");
        song.setYear("2023");

        session.save(song);

        session.getTransaction().commit();

    }
}
