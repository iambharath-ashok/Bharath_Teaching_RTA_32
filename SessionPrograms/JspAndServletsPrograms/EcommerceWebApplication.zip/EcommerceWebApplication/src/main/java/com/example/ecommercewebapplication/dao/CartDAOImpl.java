package com.example.ecommercewebapplication.dao;

import com.example.ecommercewebapplication.model.CartItem;
import com.example.ecommercewebapplication.model.Product;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CartDAOImpl implements CartDAO {
    private List<CartItem> cartItems = new ArrayList<>();

    public CartDAOImpl() {
        cartItems = new ArrayList<>();
        // Initialize with some sample items (you can modify this as needed)
        Product product1 = new Product(1, "Product A", "Description A", 10.0);
        Product product2 = new Product(2, "Product B", "Description B", 15.0);

        addToCart(product1, 2); // Add 2 units of Product A
        addToCart(product2, 1); // Add 1 unit of Product B
    }

    @Override
    public void addToCart(Product product, int quantity) {
        // Check if the product is already in the cart
        for (CartItem item : cartItems) {
            if (item.getProduct().getId() == product.getId()) {
                // If the product is already in the cart, update the quantity
                item.setQuantity(item.getQuantity() + quantity);
                return;
            }
        }
        // If the product is not in the cart, add it as a new CartItem
        CartItem newItem = new CartItem(product, quantity);
        cartItems.add(newItem);
    }

    @Override
    public void removeFromCart(int productId) {
        // Remove a product from the cart by its product ID
        Iterator<CartItem> iterator = cartItems.iterator();
        while (iterator.hasNext()) {
            CartItem item = iterator.next();
            if (item.getProduct().getId() == productId) {
                iterator.remove();
                return;
            }
        }
    }

    @Override
    public List<CartItem> getCartItems() {
        return cartItems;
    }

    @Override
    public double calculateTotalPrice() {
        double total = 0.0;
        for (CartItem item : cartItems) {
            total += item.getSubtotal();
        }
        return total;
    }

    @Override
    public void clearCart() {
        cartItems.clear();
    }
}
