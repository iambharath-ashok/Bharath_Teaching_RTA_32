package com.example.ecommercewebapplication.dao;

import com.example.ecommercewebapplication.model.Product;


import java.util.List;

public interface ProductDAO {
    /**
     * Retrieves a list of all available products.
     *
     * @return A list of Product objects.
     */
    List<Product> getAllProducts();

    /**
     * Retrieves product details by its unique identifier.
     *
     * @param productId The ID of the product to retrieve.
     * @return The Product object representing the product, or null if not found.
     */
    Product getProductById(int productId);
}
