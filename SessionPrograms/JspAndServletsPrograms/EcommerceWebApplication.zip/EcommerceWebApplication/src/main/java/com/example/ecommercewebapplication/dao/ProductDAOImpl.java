package com.example.ecommercewebapplication.dao;

import com.example.ecommercewebapplication.model.Product;

import java.util.ArrayList;
import java.util.List;

public class ProductDAOImpl implements ProductDAO {
    // Simulated in-memory product storage
    private List<Product> products;

    public ProductDAOImpl() {
        // Initialize the list of products (you can load this data from a database)
        products = new ArrayList<>();
        products.add(new Product(1, "Product 1", "Description 1", 19.99));
        products.add(new Product(2, "Product 2", "Description 2", 29.99));
        products.add(new Product(3, "Product 3", "Description 3", 39.99));
    }

    @Override
    public List<Product> getAllProducts() {
        return products;
    }

    @Override
    public Product getProductById(int productId) {
        // Find and return the product by its ID
        for (Product product : products) {
            if (product.getId() == productId) {
                return product;
            }
        }
        return null; // Product not found
    }
}
