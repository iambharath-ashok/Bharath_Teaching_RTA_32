package com.example.ecommercewebapplication.model;

import java.util.ArrayList;
import java.util.List;

public class Cart {
    private List<CartItem> items;

    public Cart() {
        items = new ArrayList<>();
    }

    public List<CartItem> getItems() {
        return items;
    }

    public void addItem(Product product, int quantity) {
        // Check if the product is already in the cart
        for (CartItem item : items) {
            if (item.getProduct().getId() == product.getId()) {
                item.setQuantity(item.getQuantity() + quantity);
                return;
            }
        }

        // If the product is not in the cart, create a new CartItem
        CartItem newItem = new CartItem(product, quantity);
        items.add(newItem);
    }

    public void removeItem(int productId) {
        // Find and remove the item with the given product ID
        items.removeIf(item -> item.getProduct().getId() == productId);
    }

    public double getTotalPrice() {
        double totalPrice = 0.0;
        for (CartItem item : items) {
            totalPrice += item.getSubtotal();
        }
        return totalPrice;
    }

    public void clear() {
        items.clear();
    }
}
