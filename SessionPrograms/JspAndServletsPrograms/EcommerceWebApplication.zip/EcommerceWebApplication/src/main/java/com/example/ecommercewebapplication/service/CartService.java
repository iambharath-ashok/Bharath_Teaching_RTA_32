package com.example.ecommercewebapplication.service;

import com.example.ecommercewebapplication.model.CartItem;
import com.example.ecommercewebapplication.model.Product;

import java.util.List;

public interface CartService {
    /**
     * Adds a product to the shopping cart with the specified quantity.
     *
     * @param product  The product to be added to the cart.
     * @param quantity The quantity of the product to add.
     */
    void addToCart(Product product, int quantity);

    /**
     * Removes a product from the shopping cart by its product ID.
     *
     * @param productId The ID of the product to remove.
     */
    void removeFromCart(int productId);

    /**
     * Retrieves the list of items in the shopping cart.
     *
     * @return A list of CartItem objects representing items in the cart.
     */
    List<CartItem> getCartItems();

    /**
     * Calculates the total price of all items in the shopping cart.
     *
     * @return The total price of items in the cart.
     */
    double calculateTotalPrice();

    /**
     * Clears the shopping cart by removing all items.
     */
    void clearCart();
}
