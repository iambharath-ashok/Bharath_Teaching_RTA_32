package com.example.ecommercewebapplication.service;


import com.example.ecommercewebapplication.dao.CartDAO;
import com.example.ecommercewebapplication.dao.CartDAOImpl;
import com.example.ecommercewebapplication.model.CartItem;
import com.example.ecommercewebapplication.model.Product;

import java.util.List;

public class CartServiceImpl implements CartService {
    private CartDAO cartDAO = new CartDAOImpl();

    @Override
    public void addToCart(Product product, int quantity) {
        // Delegate the operation to the CartDAO to update the cart in the database
        cartDAO.addToCart(product, quantity);
    }

    @Override
    public void removeFromCart(int productId) {
        // Delegate the operation to the CartDAO to remove the product from the cart in the database
        cartDAO.removeFromCart(productId);
    }

    @Override
    public List<CartItem> getCartItems() {
        // Retrieve the cart items from the CartDAO
        return cartDAO.getCartItems();
    }

    @Override
    public double calculateTotalPrice() {
        // Calculate the total price of items in the cart using the CartDAO
        return cartDAO.calculateTotalPrice();
    }

    @Override
    public void clearCart() {
        // Clear the cart using the CartDAO
        cartDAO.clearCart();
    }
}
