package com.example.ecommercewebapplication.service;

import com.example.ecommercewebapplication.dao.ProductDAO;
import com.example.ecommercewebapplication.dao.ProductDAOImpl;
import com.example.ecommercewebapplication.model.Product;


import java.util.List;

public class ProductServiceImpl implements ProductService {
    private ProductDAO productDAO = new ProductDAOImpl();

    @Override
    public List<Product> getAllProducts() {
        // In a real application, this method would retrieve product data from a database
        return productDAO.getAllProducts();
    }

    @Override
    public Product getProductById(int productId) {
        // In a real application, this method would retrieve a specific product by its ID from the database
        return productDAO.getProductById(productId);
    }
}
