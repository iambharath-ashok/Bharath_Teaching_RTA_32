package com.example.ecommercewebapplication.servlets;


import com.example.ecommercewebapplication.model.CartItem;
import com.example.ecommercewebapplication.model.Product;
import com.example.ecommercewebapplication.service.CartService;
import com.example.ecommercewebapplication.service.CartServiceImpl;
import com.example.ecommercewebapplication.service.ProductService;
import com.example.ecommercewebapplication.service.ProductServiceImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/cart")
public class CartServlet extends HttpServlet {
    private ProductService productService = new ProductServiceImpl();
    private CartService cartService = new CartServiceImpl();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the list of items in the shopping cart
        List<CartItem> cartItems = cartService.getCartItems();

        // Calculate the total price of items in the cart
        double totalPrice = cartService.calculateTotalPrice();

        // Set cart items and total price as attributes in the request
        request.setAttribute("cartItems", cartItems);
        request.setAttribute("totalPrice", totalPrice);

        // Forward the request to the cart.jsp view for rendering
        request.getRequestDispatcher("/WEB-INF/views/cart.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action != null) {
            if (action.equals("add")) {
                // Add a product to the shopping cart
                int productId = Integer.parseInt(request.getParameter("productId"));
                Product product = productService.getProductById(productId);
                int quantity = Integer.parseInt(request.getParameter("quantity"));
                cartService.addToCart(product, quantity);
            } else if (action.equals("remove")) {
                // Remove a product from the shopping cart
                int productId = Integer.parseInt(request.getParameter("productId"));
                cartService.removeFromCart(productId);
            } else if (action.equals("clear")) {
                // Clear the shopping cart
                cartService.clearCart();
            }
        }

        // Redirect back to the cart page to refresh the cart view
        response.sendRedirect(request.getContextPath() + "/cart");
    }
}
