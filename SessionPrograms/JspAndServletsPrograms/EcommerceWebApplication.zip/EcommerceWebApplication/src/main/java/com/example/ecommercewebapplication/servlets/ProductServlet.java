package com.example.ecommercewebapplication.servlets;

import com.example.ecommercewebapplication.model.Product;
import com.example.ecommercewebapplication.service.ProductService;


import com.example.ecommercewebapplication.service.ProductServiceImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/products")
public class ProductServlet extends HttpServlet {
    private ProductService productService = new ProductServiceImpl();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve a list of all available products from the ProductService
        List<Product> products = productService.getAllProducts();

        // Set the list of products as an attribute in the request
        request.setAttribute("products", products);

        // Forward the request to the product.jsp view for rendering
        request.getRequestDispatcher("/WEB-INF/views/product.jsp").forward(request, response);
    }
}
