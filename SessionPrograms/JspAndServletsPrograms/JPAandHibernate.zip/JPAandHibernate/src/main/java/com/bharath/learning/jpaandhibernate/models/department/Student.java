package com.bharath.learning.jpaandhibernate.models.department;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

//@Entity
public class Student {

    @Id
    private int id;
}
