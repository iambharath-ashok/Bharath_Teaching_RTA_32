package com.example.jspdemo;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Service
public class MyService {

    public Mono<String> fetchDataFromExternalApi(String url) {
        // Create a WebClient instance
        WebClient webClient = WebClient.create();

        return webClient.get()
            .uri(url)
            .retrieve()
            .bodyToMono(String.class);
    }
}
