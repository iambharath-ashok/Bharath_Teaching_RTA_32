package com.example.jspdemo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;

@RunWith(MockitoJUnitRunner.class)
public class MyServiceTest {

    @Mock
    private WebClient.Builder webClientBuilder;

    @Test
    public void testFetchDataFromExternalApi() {
        // Arrange
        String expectedData = "Mocked Response";
        WebClient mockedWebClient = WebClient.builder().build(); // Create a mocked WebClient

        mockStatic(WebClient.class);
        when(WebClient.builder()).thenReturn(webClientBuilder);
        when(webClientBuilder.baseUrl("https://example.com")).thenReturn(webClientBuilder);
        when(webClientBuilder.build()).thenReturn(mockedWebClient);

        when(mockedWebClient.get()).thenReturn(webClientBuilder);
        when(webClientBuilder.uri("https://example.com/api")).thenReturn(webClientBuilder);
        when(webClientBuilder.retrieve()).thenReturn(webClientBuilder);
        when(webClientBuilder.bodyToMono(String.class)).thenReturn(Mono.just(expectedData));

        MyService myService = new MyService();

        // Act
        Mono<String> result = myService.fetchDataFromExternalApi("https://example.com/api");

        // Assert
        result.subscribe(data -> {
            // Verify that the service returns the expected data
            assertEquals(expectedData, data);
        });
    }
}
