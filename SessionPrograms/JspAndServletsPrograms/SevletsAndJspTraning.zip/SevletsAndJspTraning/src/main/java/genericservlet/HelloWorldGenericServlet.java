package genericservlet;

import jakarta.servlet.annotation.WebServlet;

import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/genericServlet")
public class HelloWorldGenericServlet extends GenericServlet {

    public void init() {
        System.out.println("Initialization");
    }

    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
        // Set the content type to HTML
        response.setContentType("text/html");

        // Get a PrintWriter to write the response
        PrintWriter out = response.getWriter();

        // Write the HTML response
        out.println("<html>");
        out.println("<head><title>Hello, World Servlet</title></head>");
        out.println("<body>");
        out.println("<h1>Hello, World! From Generic Servlet</h1>");
        out.println("<p>This is a simple generic servlet example.</p>");
        out.println("</body>");
        out.println("</html>");

        // Close the PrintWriter
        out.close();
    }

    public void destroy() {
        System.out.println("Destroying");
    }

}
