package helloservlets;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/hello")
public class HelloStudentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws  IOException {
        response.setContentType("text/html");
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h1>Hello to 5 Students!</h1>");
        
        // Loop to print the message for 5 students
        for (int i = 1; i <= 5; i++) {
            response.getWriter().println("<p>Hello Student " + i + "!</p>");
        }
        
        response.getWriter().println("</body></html>");
    }
}
