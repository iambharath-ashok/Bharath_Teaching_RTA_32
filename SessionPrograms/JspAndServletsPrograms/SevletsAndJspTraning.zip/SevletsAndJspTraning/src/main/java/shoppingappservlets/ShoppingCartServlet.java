package shoppingappservlets;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/cart")
public class ShoppingCartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws  IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        // Sample shopping cart items (you can replace this with your actual cart data)
        String[] cartItems = {
            "Product 1: Laptop",
            "Product 2: Smartphone",
            "Product 3: Headphones",
            "Product 4: Camera",
            "Product 5: Smartwatch"
        };
        
        out.println("<html><body>");
        out.println("<h1>Shopping Cart</h1>");
        out.println("<ul>");
        for (String item : cartItems) {
            out.println("<li>" + item + "</li>");
        }
        out.println("</ul>");
        out.println("</body></html>");
    }
}
