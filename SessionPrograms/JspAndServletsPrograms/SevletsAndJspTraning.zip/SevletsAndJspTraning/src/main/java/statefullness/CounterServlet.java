package statefullness;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/counter")
public class CounterServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the session associated with the request or create a new one if it doesn't exist
        HttpSession session = request.getSession(true);
        
        // Get the current count from the session or initialize it to 0 if it doesn't exist
        Integer count = (Integer) session.getAttribute("count");
        if (count == null) {
            count = 0;
        }
        
        // Increment the count and store it back in the session
        count++;
        session.setAttribute("count", count);
        //request.setAttribute("count", count);
        
        // Forward to the JSP to display the count
        request.getRequestDispatcher("counter.jsp").forward(request, response);
    }
}
