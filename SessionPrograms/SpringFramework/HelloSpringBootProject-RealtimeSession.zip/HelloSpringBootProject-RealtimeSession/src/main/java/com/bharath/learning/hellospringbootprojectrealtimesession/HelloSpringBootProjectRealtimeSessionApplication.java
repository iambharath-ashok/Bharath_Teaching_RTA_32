package com.bharath.learning.hellospringbootprojectrealtimesession;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloSpringBootProjectRealtimeSessionApplication {

    public static void main(String[] args) {
        SpringApplication.run(HelloSpringBootProjectRealtimeSessionApplication.class, args);
    }

}
