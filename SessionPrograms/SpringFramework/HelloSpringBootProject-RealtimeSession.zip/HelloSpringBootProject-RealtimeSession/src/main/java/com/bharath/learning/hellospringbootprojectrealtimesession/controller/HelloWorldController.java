package com.bharath.learning.hellospringbootprojectrealtimesession.controller;

import com.bharath.learning.hellospringbootprojectrealtimesession.bean.HelloWorldBean;
import com.bharath.learning.hellospringbootprojectrealtimesession.service.HelloWorldService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

@RestController
public class HelloWorldController {

    @Autowired
    private HelloWorldService helloWorldService;


    @GetMapping("/hello")
    public String helloWorldString() {
        return "Hello, Welcome to Spring Boot World";
    }


    @GetMapping(value = "/hello-world-bean", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<HelloWorldBean> helloWorldBean() {
        return ResponseEntity.ok(new HelloWorldBean("Hello, Welcome to API Dev", LocalDateTime.now()));
    }


    @GetMapping("/hello-world-bean-repo")
    public HelloWorldBean getHelloWorldBeanFromRepo() {
       return this.helloWorldService.processHelloWorldRequest();
    }


}
