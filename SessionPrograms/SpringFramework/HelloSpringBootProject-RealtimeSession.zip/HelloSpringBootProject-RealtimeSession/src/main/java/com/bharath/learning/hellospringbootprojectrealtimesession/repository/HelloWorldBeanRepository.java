package com.bharath.learning.hellospringbootprojectrealtimesession.repository;

import com.bharath.learning.hellospringbootprojectrealtimesession.bean.HelloWorldBean;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;

@Repository
public class HelloWorldBeanRepository {


    public HelloWorldBean fetchHelloWorldBean() {
       return new HelloWorldBean("Hello from Repo", LocalDateTime.now());
    }
}
