package com.bharath.learning.hellospringbootprojectrealtimesession.service;

import com.bharath.learning.hellospringbootprojectrealtimesession.bean.HelloWorldBean;
import com.bharath.learning.hellospringbootprojectrealtimesession.repository.HelloWorldBeanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HelloWorldService {

    @Autowired
    private HelloWorldBeanRepository helloWorldBeanRepository;

    public HelloWorldBean processHelloWorldRequest() {
        return helloWorldBeanRepository.fetchHelloWorldBean();
    }

}
