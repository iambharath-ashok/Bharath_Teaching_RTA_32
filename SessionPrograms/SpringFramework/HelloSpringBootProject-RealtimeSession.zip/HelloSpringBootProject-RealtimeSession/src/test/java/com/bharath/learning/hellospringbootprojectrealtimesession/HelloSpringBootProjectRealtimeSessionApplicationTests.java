package com.bharath.learning.hellospringbootprojectrealtimesession;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloSpringBootProjectRealtimeSessionApplicationTests {

    @Test
    void contextLoads() {
    }

}
