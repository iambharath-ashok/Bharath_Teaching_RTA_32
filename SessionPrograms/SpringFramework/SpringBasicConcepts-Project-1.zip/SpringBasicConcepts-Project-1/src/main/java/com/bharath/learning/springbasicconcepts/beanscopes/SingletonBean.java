package com.bharath.learning.springbasicconcepts.beanscopes;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
public class SingletonBean {

    private int counter = 0;

    public void incrementCounter() {
        this.counter++;
    }

    public int getCounter() {
        return this.counter;
    }


}
