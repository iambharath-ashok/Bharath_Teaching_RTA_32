package com.bharath.learning.springbasicconcepts.beanscopes;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SingletonSpringMainRunner {

    public static void main(String[] args) {


        ApplicationContext context = new AnnotationConfigApplicationContext(SingletonScopeConfig.class);

        SingletonBean singletonBean1 = context.getBean(SingletonBean.class);
        SingletonBean singletonBean2 = context.getBean(SingletonBean.class);
        SingletonBean singletonBean3 = context.getBean(SingletonBean.class);
        SingletonBean singletonBean4 = context.getBean(SingletonBean.class);
        SingletonBean singletonBean5 = context.getBean(SingletonBean.class);


        singletonBean1.incrementCounter();
        singletonBean2.incrementCounter();
        singletonBean3.incrementCounter();
        singletonBean4.incrementCounter();
        singletonBean5.incrementCounter();

        System.out.println(singletonBean3.getCounter());
        System.out.println(singletonBean5.getCounter());

    }
}
