package com.bharath.learning.springbasicconcepts.injections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class BankService {


    //DI via IOC
    @Autowired
    @Qualifier("consoleLogger")
    private TransactionLogger transactionLogger;

    //Constructor
    //Setter
    //Field level


//    // Constructor Injection
//    public BankService(@Autowired @Qualifier("consoleLogger")TransactionLogger transactionLogger) {
//        this.transactionLogger = transactionLogger;
//    }


//    @Autowired
//    @Qualifier("consoleLogger")
//    public void setTransactionLogger(TransactionLogger transactionLogger) {
//        this.transactionLogger = transactionLogger;
//    }

    public void deposit(int amount) {
        transactionLogger.logTransaction("Deposit Of Amount Rs::" + amount);
    }

    public void withdraw(int amount) {
        transactionLogger.logTransaction("Withdrawal Of Amount Rs::" + amount);
    }

}
