package com.bharath.learning.springbasicconcepts.injections;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class ConsoleLogger implements TransactionLogger {
    @Override
    public void logTransaction(String message) {
        System.out.println("Transaction Log Message:: "+ message);
    }
}
