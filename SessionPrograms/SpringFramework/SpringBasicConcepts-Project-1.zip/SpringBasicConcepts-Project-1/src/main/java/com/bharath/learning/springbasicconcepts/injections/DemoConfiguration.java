package com.bharath.learning.springbasicconcepts.injections;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.bharath.learning.springbasicconcepts.injections")
public class DemoConfiguration {

}
