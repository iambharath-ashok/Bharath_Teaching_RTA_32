package com.bharath.learning.springbasicconcepts.injections;

import org.springframework.stereotype.Component;

@Component
public class ElasticSearchLogger implements  TransactionLogger {
    @Override
    public void logTransaction(String message) {
        System.out.println("Logging to ELK:: "+ message);
    }
}
