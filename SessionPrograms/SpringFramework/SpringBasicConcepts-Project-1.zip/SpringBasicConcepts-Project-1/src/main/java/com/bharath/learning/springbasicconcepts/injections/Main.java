package com.bharath.learning.springbasicconcepts.injections;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

    public static void main(String[] args) {

        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(DemoConfiguration.class);

       BankService bankService = applicationContext.getBean(BankService.class);
       TransactionLogger transactionLogger = applicationContext.getBean("elasticSearchLogger",TransactionLogger.class);

        System.out.println(bankService);
        System.out.println(transactionLogger);

        bankService.deposit(100);

    }
}
