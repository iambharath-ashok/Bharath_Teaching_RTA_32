package com.bharath.learning.springbasicconcepts.injections;

public interface TransactionLogger {
    void logTransaction(String message);
}
