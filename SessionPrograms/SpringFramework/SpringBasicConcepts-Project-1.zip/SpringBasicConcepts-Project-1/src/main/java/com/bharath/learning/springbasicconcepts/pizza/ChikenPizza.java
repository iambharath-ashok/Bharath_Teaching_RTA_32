package com.bharath.learning.springbasicconcepts.pizza;

import org.springframework.stereotype.Component;

@Component
public class ChikenPizza implements Pizza{
    @Override
    public void preparePizza() {
        System.out.println("Preparing Chiken Pizza");
    }

    @Override
    public void bakePizza() {
        System.out.println("Baking Chiken Pizza");
    }

    @Override
    public void cutPizza() {
        System.out.println("Cutting Chiken Pizza");
    }
}
