package com.bharath.learning.springbasicconcepts.pizza;

public interface Pizza {

    void preparePizza();
    void bakePizza();
    void cutPizza();

}
