package com.bharath.learning.springbasicconcepts.pizza;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class PizzaDelivery {

    public static void main(String[] args) {

        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(PizzaConfiguration.class);

        PizzaStore pizzaStore = applicationContext.getBean(PizzaStore.class);
        pizzaStore.prepareOrder();


    }
}
