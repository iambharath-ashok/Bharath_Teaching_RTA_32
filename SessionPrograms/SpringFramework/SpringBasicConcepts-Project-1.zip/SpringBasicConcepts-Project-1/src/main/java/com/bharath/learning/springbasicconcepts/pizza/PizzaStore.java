package com.bharath.learning.springbasicconcepts.pizza;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class PizzaStore {

    private Pizza pizza;

    @Autowired
    @Qualifier("chikenPizza")
    public void setPizza(Pizza pizza) {
        this.pizza = pizza;
    }

    public Pizza prepareOrder() {
        pizza.preparePizza();
        pizza.bakePizza();
        pizza.cutPizza();
        return pizza;
    }
}
