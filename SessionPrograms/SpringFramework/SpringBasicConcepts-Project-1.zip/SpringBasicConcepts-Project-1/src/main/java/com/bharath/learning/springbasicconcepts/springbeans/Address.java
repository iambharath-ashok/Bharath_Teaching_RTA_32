package com.bharath.learning.springbasicconcepts.springbeans;

import java.io.Serializable;

//Java Beans
public class Address  implements Serializable {

    public Address() {}

    private String street;

    public String getStreet() {
        return "Nyc";
    }

    public void setStreet(String street) {
        this.street = street;
    }

}
