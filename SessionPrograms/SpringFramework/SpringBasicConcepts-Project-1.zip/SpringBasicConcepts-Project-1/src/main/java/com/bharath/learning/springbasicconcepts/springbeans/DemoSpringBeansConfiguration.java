package com.bharath.learning.springbasicconcepts.springbeans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DemoSpringBeansConfiguration {

    @Bean
    public String firstName() {
        return "Bikash";
    }

    @Bean
    public String lastName() {
        return "Kumar";
    }

    @Bean
    public int age() {
        return 21;
    }

    @Bean
    public Person bharath() {
        Person person = new Person("bharath", "Ashok", 19);
        return person;
    }


    //this is not depenency injection
    // below is just normal java invocation
    @Bean
    public Person bikash() {
        Person person = new Person(firstName(), lastName(), age());
        return person;
    }

    @Bean
    public Person bikash_throuh_di(String firstName, String lastName, int age) {

        //Constructor Based Injection
        Person person = new Person(firstName, lastName, age);
        return person;
    }

}
