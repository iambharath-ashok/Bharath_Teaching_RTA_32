package com.bharath.learning.springbasicconcepts.springbeans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.Arrays;

public class SpringBeansExampleApplicationRunner {

    public static void main(String[] args) {

        //Creating a Spring Container
        //Spring container or IOC container
        //Spring context
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(DemoSpringBeansConfiguration.class);

        String name = applicationContext.getBean("firstName", String.class);
        int age = applicationContext.getBean("age", Integer.class);

        System.out.println(name);
        System.out.println(age);

        System.out.println(Arrays.deepToString(applicationContext.getBeanDefinitionNames()));

        System.out.println("====================================================================================");

        Person bharath = applicationContext.getBean("bharath", Person.class);

        System.out.println(bharath);


        Person bikash = applicationContext.getBean("bikash", Person.class);

        System.out.println(bikash);



        Person bikash_throuh_di = applicationContext.getBean("bikash_throuh_di", Person.class);

        System.out.println(bikash_throuh_di);
    }
}
