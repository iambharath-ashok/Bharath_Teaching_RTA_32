package com.bharath.learning.springbasicexample.injections;

public interface TransactionLogger {

    void logTransaaction(String message);

}
