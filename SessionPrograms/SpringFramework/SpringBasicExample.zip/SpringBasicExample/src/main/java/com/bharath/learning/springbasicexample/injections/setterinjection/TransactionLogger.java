package com.bharath.learning.springbasicexample.injections.setterinjection;

public interface TransactionLogger {
    void logTransaction(String message);
}
