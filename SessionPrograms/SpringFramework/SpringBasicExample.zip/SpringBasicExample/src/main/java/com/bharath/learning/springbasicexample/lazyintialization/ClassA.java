package com.bharath.learning.springbasicexample.lazyintialization;

import org.springframework.stereotype.Component;

@Component
public class ClassA {
}
