package com.bharath.learning.springbasicexample.pizza;

public interface Pizza {

     void preparePizza();
     void bakePizza();
    void cutPizza();
}
