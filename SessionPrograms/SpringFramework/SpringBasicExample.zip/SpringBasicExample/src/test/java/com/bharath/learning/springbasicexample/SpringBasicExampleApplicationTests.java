package com.bharath.learning.springbasicexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBasicExampleApplicationTests {

    @Test
    void contextLoads() {
    }

}
