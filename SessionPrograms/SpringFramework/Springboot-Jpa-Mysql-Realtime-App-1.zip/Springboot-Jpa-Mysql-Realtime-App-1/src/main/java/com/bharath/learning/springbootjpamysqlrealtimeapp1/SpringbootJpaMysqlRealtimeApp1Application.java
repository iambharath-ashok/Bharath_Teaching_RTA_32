package com.bharath.learning.springbootjpamysqlrealtimeapp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootJpaMysqlRealtimeApp1Application {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootJpaMysqlRealtimeApp1Application.class, args);
    }

}
