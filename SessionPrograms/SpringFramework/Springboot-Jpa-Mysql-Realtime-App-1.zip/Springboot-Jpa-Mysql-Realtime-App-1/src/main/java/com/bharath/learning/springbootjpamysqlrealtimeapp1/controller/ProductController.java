package com.bharath.learning.springbootjpamysqlrealtimeapp1.controller;

import com.bharath.learning.springbootjpamysqlrealtimeapp1.model.Product;
import com.bharath.learning.springbootjpamysqlrealtimeapp1.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController("/product/api/v1")
public class ProductController {

    @Autowired
    ProductService productService;


    //GET ALL PRODUCTS
    @GetMapping("/findAll")
    public List<Product> fetchAllProducts() {
       List<Product> productList =  productService.fetchAllProducts();
       return  productList;
    }


    //GET PRODUCT BY ID
    //GET PRODUCT BY NAME
    //CREATE/SAVE NEW PRODUCT
    //UPDATE PRODUCT
    //DELETE PRODUCT


}
