package com.bharath.learning.springbootjpamysqlrealtimeapp1.repository;

import com.bharath.learning.springbootjpamysqlrealtimeapp1.model.Product;

import java.util.List;

public interface ProductDAO {

    void insert(Product product);

    List<Product> fetchAll();

    Product findById(int id);

    Product updateById(Product productToBeUpdate, int id);

    boolean deleteById(int id);


}
