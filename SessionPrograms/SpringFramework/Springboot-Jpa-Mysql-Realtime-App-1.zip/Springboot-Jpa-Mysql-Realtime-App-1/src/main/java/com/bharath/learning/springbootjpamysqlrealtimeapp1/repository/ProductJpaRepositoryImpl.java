package com.bharath.learning.springbootjpamysqlrealtimeapp1.repository;

import com.bharath.learning.springbootjpamysqlrealtimeapp1.model.Product;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


//JPA and Hibernate Implementation
@Repository
@Transactional
public class ProductJpaRepositoryImpl implements ProductDAO{

   @PersistenceContext
    private EntityManager entityManager;


    @Override
    public void insert(Product product) {
        entityManager.merge(product);
    }

    @Override
    public List<Product> fetchAll() {
        return entityManager.createQuery( "SELECT p from Product p", Product.class).getResultList();
    }

    @Override
    public Product findById(int id) {
        return entityManager.find(Product.class, id);
    }

    @Override
    public Product updateById(Product productToBeUpdate, int id) {
        Product originalProduct = entityManager.find(Product.class, id);
        originalProduct.setDescription(productToBeUpdate.getDescription());
        originalProduct.setName(productToBeUpdate.getName());
        originalProduct.setPrice(productToBeUpdate.getPrice());
        originalProduct.setStockQuantity(productToBeUpdate.getStockQuantity());
        Product updatedProduct = entityManager.merge(originalProduct);
        return updatedProduct;
    }

    @Override
    public boolean deleteById(int id) {
        Product productToBeDeleted = entityManager.find(Product.class, id);
        entityManager.remove(productToBeDeleted);
        return true;
    }
}
