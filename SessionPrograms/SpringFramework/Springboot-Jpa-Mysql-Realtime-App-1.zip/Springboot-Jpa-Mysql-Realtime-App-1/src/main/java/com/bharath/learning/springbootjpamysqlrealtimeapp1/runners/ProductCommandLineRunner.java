package com.bharath.learning.springbootjpamysqlrealtimeapp1.runners;

import com.bharath.learning.springbootjpamysqlrealtimeapp1.model.Product;
import com.bharath.learning.springbootjpamysqlrealtimeapp1.repository.ProductDAO;
import com.bharath.learning.springbootjpamysqlrealtimeapp1.repository.ProductSpringDataJpaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ProductCommandLineRunner implements CommandLineRunner {

    @Autowired
    private ProductDAO productJpaRepositoryImpl;

    @Autowired
    private ProductSpringDataJpaRepository productSpringDataJpaRepositoryImpl;


    @Override
    public void run(String... args) throws Exception {

        Product samsungFoldz3rdGen = new Product("Samsung Z Fold", "Fold Generation Mobile",1000.0, 10);
//        productJpaRepositoryImpl.insert(samsungFoldz3rdGen);

       // Insert
        productSpringDataJpaRepositoryImpl.save(samsungFoldz3rdGen);
        productSpringDataJpaRepositoryImpl.save(samsungFoldz3rdGen);

       // List<Product> productList = productJpaRepositoryImpl.fetchAll();

        //Find
        List<Product> productList =  productSpringDataJpaRepositoryImpl.findAll();

        for (Product product : productList) {
            System.out.println(product.getName());
            System.out.println(product.getDescription());
        }

        // Find
      //  Product product = productJpaRepositoryImpl.findById(3);
        Product product =   productSpringDataJpaRepositoryImpl.findById(3).get();

        System.out.println(product.getDescription());


        System.out.println("================================================================");
        Product iPhone = new Product("Iphone", "IPhone Latest Gen",500.0, 5);
        Product samsungTablet = new Product("Samsung Tablet", "Tablet",10000.0, 10);
       // productJpaRepositoryImpl.updateById(iPhone, 2);

        // Updating the existing resource
        //Update
       Product existingProduct = productSpringDataJpaRepositoryImpl.getById(2);
       Product appleVisionPro = new Product("Apple Vision", "Virtual Reality", 3599.0, 4);
       existingProduct.setName(appleVisionPro.getName());
       existingProduct.setPrice(appleVisionPro.getPrice());
       existingProduct.setDescription(appleVisionPro.getDescription());
       existingProduct.setStockQuantity(appleVisionPro.getStockQuantity());
       productSpringDataJpaRepositoryImpl.save(existingProduct);

        //productJpaRepositoryImpl.deleteById(4);
        //Delete
        productSpringDataJpaRepositoryImpl.deleteById(2);
    }
}
