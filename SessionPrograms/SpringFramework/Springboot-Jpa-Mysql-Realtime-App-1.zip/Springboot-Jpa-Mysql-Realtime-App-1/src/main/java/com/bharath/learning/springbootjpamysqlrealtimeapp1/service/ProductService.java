package com.bharath.learning.springbootjpamysqlrealtimeapp1.service;

import com.bharath.learning.springbootjpamysqlrealtimeapp1.model.Product;
import com.bharath.learning.springbootjpamysqlrealtimeapp1.repository.ProductSpringDataJpaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    @Autowired
    private ProductSpringDataJpaRepository productSpringDataJpaRepository;

    public List<Product> fetchAllProducts() {
        return productSpringDataJpaRepository.findAll();
    }

}
