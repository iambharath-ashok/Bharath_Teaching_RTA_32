package com.bharath.learning.springbootjpamysqlrealtimeapp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootJpaMysqlRealtimeApp1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
